username = input('username: ')
print('欢迎:', username)
print('欢迎: ' + username)
