# print("Hello World!")
#
# if 3 > 0:
#     print('yes')
#     print('OK')
#
# if 3 > 0: print('yes')   # 语法正确，但是可读性不好，不推荐


a = 10
print(a)
a
