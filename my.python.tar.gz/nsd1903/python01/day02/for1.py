astr = 'hao123'
alist = ['tom', 'jerry', 'bob']
atuple = (10, 20, 30, 25)
adict = {'name': 'tom', 'age': 22}

for ch in astr:
    print(ch)

for name in alist:
    print(name)

for i in atuple:
    print(i)

for key in adict:
    print(key, adict[key])
