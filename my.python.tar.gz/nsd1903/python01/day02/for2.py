# result = 0
#
# for i in range(1, 101):
#     result += i
#
# print(result)
#############################
result = 0

for i in range(2, 101, 2):
    result += i

print(result)

