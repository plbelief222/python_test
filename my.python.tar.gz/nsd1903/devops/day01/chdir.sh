#!/bin/bash

cd /home
